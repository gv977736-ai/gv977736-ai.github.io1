const IMG=[
 "img/01-mpb.jpg",
 "img/02-rap.jpg",
 "img/03-blues.jpg",
 "img/04-pagode.jpg",
 "img/05-classica.jpg",
 "img/06-reggae.jpg",
 "img/07-samba.jpg",
 "img/08-funk.jpg",
 "img/09-eletronica.jpg",
 "img/10-sertanejo.jpg",
 "img/11-forro.jpg",
 "img/12-jazz.jpg",
 "img/13-rock.jpg",
 "img/14-metal.jpg",
 "img/15-pop.jpg"
];

(function(){
const reduce=matchMedia("(prefers-reduced-motion:reduce)").matches;
let R=null,S=[];
const sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(28,1,.1,20);cam.position.z=5.2;
try{
 const cv=document.createElement("canvas");cv.id="gl";document.body.appendChild(cv);
 R=new THREE.WebGLRenderer({canvas:cv,alpha:true,antialias:true});R.setClearColor(0x000000,0);R.autoClear=false;R.outputEncoding=THREE.sRGBEncoding;
}catch(e){R=null}
sc.add(new THREE.AmbientLight(0xffffff,.95));
const L=new THREE.DirectionalLight(0xffffff,1.15);L.position.set(-2,3,4);sc.add(L);
const L2=new THREE.PointLight(0xd4af37,.8,12);L2.position.set(2.5,-1.5,2);sc.add(L2);
const sk=document.createElement("canvas");sk.width=sk.height=256;const x=sk.getContext("2d");
if(x.createConicGradient){const g=x.createConicGradient(.4,128,128);[[0,0],[.06,.5],[.14,0],[.5,0],[.6,.4],[.7,0],[1,0]].forEach(a=>g.addColorStop(a[0],"rgba(255,255,255,"+a[1]+")"));x.fillStyle=g;x.fillRect(0,0,256,256)}
function rad(st){const c=document.createElement("canvas");c.width=c.height=128;const q=c.getContext("2d"),g=q.createRadialGradient(64,64,0,64,64,64);st.forEach(a=>g.addColorStop(a[0],a[1]));q.fillStyle=g;q.fillRect(0,0,128,128);return new THREE.CanvasTexture(c)}
const glowT=rad([[0,"rgba(255,255,255,0)"],[.6,"rgba(255,255,255,.12)"],[.77,"rgba(255,255,255,.9)"],[1,"rgba(255,255,255,0)"]]),shT=rad([[0,"rgba(0,0,0,.9)"],[.75,"rgba(0,0,0,.6)"],[1,"rgba(0,0,0,0)"]]);
const sheenT=new THREE.CanvasTexture(sk),loader=new THREE.TextureLoader(),TX={};
const tx=i=>TX[i]||(TX[i]=(t=>{t=loader.load(IMG[i]);t.encoding=THREE.sRGBEncoding;t.anisotropy=4;return t})());
function build(i,col){
 const g=new THREE.Group(),pv=new THREE.Group(),disc=new THREE.Group();g.add(pv);pv.add(disc);
 const face=new THREE.Mesh(new THREE.CircleGeometry(1,96),new THREE.MeshStandardMaterial({map:tx(i),roughness:.3,metalness:.2,emissive:0xffffff,emissiveMap:tx(i),emissiveIntensity:.18}));face.position.z=.03;
 const back=new THREE.Mesh(new THREE.CircleGeometry(1,64),new THREE.MeshStandardMaterial({color:0x0b0b10,roughness:.4,metalness:.5}));back.rotation.y=Math.PI;back.position.z=-.03;
 const side=new THREE.Mesh(new THREE.CylinderGeometry(1,1,.06,96,1,true),new THREE.MeshStandardMaterial({color:0x16161c,roughness:.3,metalness:.6}));side.rotation.x=Math.PI/2;
 const rim=new THREE.Mesh(new THREE.RingGeometry(.955,1,96),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.28,depthWrite:false}));rim.position.z=.032;
 disc.add(face,back,side,rim);
 const sh=new THREE.Mesh(new THREE.CircleGeometry(1,64),new THREE.MeshBasicMaterial({map:sheenT,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));sh.position.z=.04;pv.add(sh);
 const ha=new THREE.Mesh(new THREE.CircleGeometry(1.3,64),new THREE.MeshBasicMaterial({map:glowT,color:new THREE.Color(col),transparent:true,opacity:.5,blending:THREE.AdditiveBlending,depthWrite:false}));ha.position.z=-.25;g.add(ha);
 const sd=new THREE.Mesh(new THREE.CircleGeometry(1.2,64),new THREE.MeshBasicMaterial({map:shT,transparent:true,opacity:.7,depthWrite:false}));sd.position.set(.1,-.16,-.3);g.add(sd);
 return{g,pv,disc,sh,halo:ha};
}
function rs(){if(!R)return;R.setPixelRatio(Math.min(devicePixelRatio,2));R.setSize(innerWidth,innerHeight)}
addEventListener("resize",rs);rs();
window.glScan=function(){
 S.forEach(s=>s.o&&s.o.g.traverse(n=>{n.geometry&&n.geometry.dispose();n.material&&n.material.dispose()}));
 S=[...document.querySelectorAll(".dw[data-i]")].map(el=>{const i=+el.dataset.i;
  if(!R){el.style.background="url("+IMG[i]+") center/cover";return{el}}
  return{el,o:build(i,getComputedStyle(el).getPropertyValue("--c").trim()||"#D4AF37"),rx:0,ry:0,h:0,big:!!el.closest(".big,.duo"),sp:Math.random()*6}});
};
let t0=performance.now();
function loop(t){requestAnimationFrame(loop);if(!R)return;
 const dt=Math.min((t-t0)/1000,.05);t0=t;R.setScissorTest(false);R.clear();R.setScissorTest(true);const H=innerHeight;
 for(const s of S){const r=s.el.getBoundingClientRect();if(r.bottom<0||r.top>H||r.width<2)continue;
  const h=s.el.closest("[data-t]")||s.el;if(+getComputedStyle(h).opacity<.6)continue;
  const hov=h.matches(":hover")||h.classList.contains("on");
  s.rx+=((h._ty||0)-s.rx)*.12;s.ry+=((h._tx||0)-s.ry)*.12;
  if(!hov&&!reduce)s.sp+=dt*.7;
  s.o.disc.rotation.z=-s.sp;s.o.pv.rotation.set(s.rx,s.ry,0);s.o.sh.rotation.z=-s.ry*5;
  const k=1.3,w=r.width*k,x0=r.left-(w-r.width)/2,y0=H-r.bottom-(w-r.height)/2;
  s.h+=((hov?1:0)-s.h)*.1;s.o.halo.material.opacity=(s.big?.85:.5)+s.h*.5;
  sc.add(s.o.g);R.setViewport(x0,y0,w,w);R.setScissor(x0,y0,w,w);R.clearDepth();R.render(sc,cam);sc.remove(s.o.g);}
}
requestAnimationFrame(loop);
})();


// [slug, nome, cor, sensação, origem, [ritmo, instrumentos, letras], artistas, [[música, artista, ano]]]
const G=[
["mpb","MPB","#C8553D","Identidade","Consolidada nos anos 1960, a MPB une samba, bossa nova e influências regionais em canções de forte poesia.",["Mistura samba, bossa nova e ritmos regionais","Violão, piano e orquestrações","Poesia, crônica social e protesto"],"Chico Buarque,Elis Regina,Caetano Veloso,Gilberto Gil",[["Construção","Chico Buarque","1971"],["Águas de Março","Tom Jobim","1972"],["Sampa","Caetano Veloso","1978"]]],
["rap","Rap","#E63946","Atitude","Nasceu nos anos 1970 no Bronx, em Nova York, dentro da cultura hip-hop, e chegou ao Brasil nos anos 1980.",["Rimas faladas sobre bases rítmicas","MC, DJ, toca-discos e samplers","Relatos da vida urbana e crítica social"],"Racionais MC’s,Emicida,Tupac,Kendrick Lamar",[["Diário de um Detento","Racionais MC’s","1997"],["Juicy","The Notorious B.I.G.","1994"],["Passarinhos","Emicida","2015"]]],
["blues","Blues","#2F6FED","Sentimento","Surgiu entre comunidades afro-americanas do sul dos Estados Unidos, no fim do século XIX, e deu base ao jazz e ao rock.",["Estrutura clássica de 12 compassos","Guitarra, gaita e piano","Dor, amor e superação"],"B.B. King,Muddy Waters,Robert Johnson,Etta James",[["Cross Road Blues","Robert Johnson","1936"],["Hoochie Coochie Man","Muddy Waters","1954"],["The Thrill Is Gone","B.B. King","1969"]]],
["pagode","Pagode","#FF8C1A","Alegria","Nasceu nos anos 1970 nas rodas de samba dos quintais do Rio de Janeiro e conquistou o país nas décadas seguintes.",["Samba de roda e partido-alto","Cavaquinho, banjo, tantã e repique de mão","Amor, festa e cotidiano"],"Zeca Pagodinho,Beth Carvalho,Fundo de Quintal,Revelação",[["Vou Festejar","Beth Carvalho","1978"],["Deixa a Vida Me Levar","Zeca Pagodinho","2002"]]],
["classica","Música clássica","#D4AF37","Elegância","Reúne a longa tradição erudita ocidental, cujo período clássico vai de cerca de 1750 a 1820, com Haydn, Mozart e Beethoven.",["Formas elaboradas, como sinfonia e sonata","Orquestra, piano e música de câmara","Em geral, instrumental"],"Bach,Mozart,Beethoven,Chopin",[["Prelúdio em Dó maior","J. S. Bach","1722"],["Eine kleine Nachtmusik","Mozart","1787"],["Sinfonia nº 5","Beethoven","1808"]]],
["reggae","Reggae","#2EB872","Liberdade","Surgiu na Jamaica no fim dos anos 1960, a partir do ska e do rocksteady, e levou ao mundo a voz de Bob Marley.",["Contratempo marcante e andamento moderado","Baixo, guitarra, bateria e teclado","Paz, fé e justiça social"],"Bob Marley,Peter Tosh,Jimmy Cliff,Toots Hibbert",[["Many Rivers to Cross","Jimmy Cliff","1969"],["No Woman, No Cry","Bob Marley","1974"],["Redemption Song","Bob Marley","1980"]]],
["samba","Samba","#FFD21F","Celebração","De raízes afro-brasileiras, ganhou forma no Rio de Janeiro no início do século XX e virou símbolo do país.",["Ritmo sincopado e envolvente","Surdo, pandeiro, cavaquinho e violão","Amor, cotidiano e crônicas do povo"],"Cartola,Noel Rosa,Clara Nunes,Dona Ivone Lara",[["Pelo Telefone","Donga","1917"],["As Rosas Não Falam","Cartola","1976"]]],
["funk","Funk","#8E44FF","Expressão","O funk carioca ganhou força nos bailes do Rio nos anos 1980, com influência da black music e do Miami bass.",["Batida marcante com bases eletrônicas","MC, DJ e baixos pesados","Dança, vida na comunidade e romance"],"Claudinho & Buchecha,MC Marcinho,Tati Quebra Barraco,Anitta",[["Rap das Armas","MC Cidinho & MC Doca","2008"],["Fico Assim Sem Você","Claudinho & Buchecha","1999"]]],
["eletronica","Eletrônica","#22D3EE","Tecnologia","Feita com sintetizadores e computadores, ganhou forma nos anos 1970 e 1980 com o Kraftwerk, o house de Chicago e o techno de Detroit.",["Batidas programadas e repetitivas","Sintetizadores, samplers e computador","Predominantemente instrumental"],"Kraftwerk,Daft Punk,Avicii,Alok",[["Autobahn","Kraftwerk","1974"],["One More Time","Daft Punk","2000"],["Levels","Avicii","2011"]]],
["sertanejo","Sertanejo","#8B5A3C","Tradição","Vem da música caipira do interior do Brasil e, ao longo do século XX, ganhou o rádio e os palcos com as duplas.",["Melodias simples e duplas a duas vozes","Viola caipira, violão e sanfona","Amor, saudade e vida no campo"],"Tonico & Tinoco,Chitãozinho & Xororó,Zezé Di Camargo & Luciano,Marília Mendonça",[["Evidências","Chitãozinho & Xororó","1990"],["Infiel","Marília Mendonça","2016"]]],
["forro","Forró","#CC5500","Aconchego","Nasceu no Nordeste e foi popularizado a partir dos anos 1940 por Luiz Gonzaga e seu baião.",["Ritmo para dançar em par: baião, xote e xaxado","Sanfona, zabumba e triângulo","Amor, saudade e vida no sertão"],"Luiz Gonzaga,Dominguinhos,Jackson do Pandeiro,Elba Ramalho",[["Baião","Luiz Gonzaga","1946"],["Asa Branca","Luiz Gonzaga","1947"],["Sebastiana","Jackson do Pandeiro","1953"]]],
["jazz","Jazz","#1B2F6B","Sofisticação","Nasceu em Nova Orleans, nos Estados Unidos, no início do século XX, da mistura de blues, ragtime e música de bandas.",["Improvisação e swing","Saxofone, trompete, piano e contrabaixo","Muito instrumental, com grandes vozes"],"Louis Armstrong,Miles Davis,Ella Fitzgerald,John Coltrane",[["So What","Miles Davis","1959"],["Take Five","Dave Brubeck","1959"],["What a Wonderful World","Louis Armstrong","1967"]]],
["rock","Rock","#8B1A1A","Rebeldia","Surgiu nos Estados Unidos nos anos 1950, a partir do blues e do rhythm and blues, com nomes como Chuck Berry e Elvis Presley.",["Batida forte e guitarras marcantes","Guitarra, baixo e bateria","Juventude, liberdade e rebeldia"],"Elvis Presley,The Beatles,Queen,Rita Lee",[["Rock Around the Clock","Bill Haley","1954"],["Bohemian Rhapsody","Queen","1975"]]],
["metal","Metal","#9AA3AD","Intensidade","O heavy metal surgiu no fim dos anos 1960 na Inglaterra, com o Black Sabbath, e se espalhou em vários subgêneros.",["Andamentos rápidos e riffs pesados","Guitarras distorcidas e bateria dupla","Temas sombrios, épicos e críticas sociais"],"Black Sabbath,Metallica,Iron Maiden,Sepultura",[["Paranoid","Black Sabbath","1970"],["Master of Puppets","Metallica","1986"],["Roots Bloody Roots","Sepultura","1996"]]],
["pop","Pop","#FF5FA2","Criatividade","O pop é a música popular feita para grandes públicos, consolidada ao longo da segunda metade do século XX.",["Melodias fáceis e refrões marcantes","Voz em destaque, sintetizadores e bateria","Amor, superação e temas do cotidiano"],"Michael Jackson,Madonna,Beyoncé,Taylor Swift",[["Billie Jean","Michael Jackson","1983"],["Like a Prayer","Madonna","1989"],["Halo","Beyoncé","2008"]]]
].map(a=>({s:a[0],n:a[1],c:a[2],f:a[3],o:a[4],k:a[5],a:a[6].split(","),m:a[7]}));

const C={
mpb:["Os festivais da canção da TV, nos anos 1960, revelaram nomes como Chico Buarque, Elis Regina e Gilberto Gil.","A sigla MPB passou a designar a música brasileira feita depois da bossa nova."],
rap:["O DJ Kool Herc é apontado como um dos pioneiros do hip-hop, com festas no Bronx no início dos anos 1970.","O hip-hop tem quatro elementos: MC, DJ, breaking e grafite."],
blues:["O nome vem da expressão inglesa “feeling blue”, que significa sentir-se triste.","Diz a lenda que Robert Johnson vendeu a alma ao diabo numa encruzilhada para tocar tão bem."],
pagode:["As rodas do Cacique de Ramos, no Rio de Janeiro, são lembradas como berço do pagode de quintal.","O grupo Fundo de Quintal ficou conhecido por incluir banjo, tantã e repique de mão no samba."],
classica:["Beethoven continuou compondo mesmo depois de ficar surdo.","Mozart começou a compor ainda criança."],
reggae:["Em 2018, a Unesco reconheceu o reggae da Jamaica como patrimônio cultural imaterial da humanidade.","O reggae tem forte ligação com o movimento rastafári."],
samba:["“Pelo Telefone”, de 1917, é lembrado como o primeiro samba gravado.","O samba carioca foi registrado como patrimônio cultural do Brasil pelo Iphan em 2007."],
funk:["O funk original surgiu nos Estados Unidos nos anos 1960, com James Brown como um dos grandes nomes.","No Rio de Janeiro, uma lei de 2009 reconheceu o funk como movimento cultural e musical de caráter popular."],
eletronica:["Os primeiros sintetizadores comerciais, como o Moog, surgiram nos anos 1960.","O Daft Punk fez dos capacetes de robô sua marca registrada."],
sertanejo:["A viola caipira tem dez cordas, organizadas em cinco pares.","As duplas costumam cantar a duas vozes, em harmonia."],
forro:["A palavra forró designa tanto o ritmo quanto a festa de dança.","Luiz Gonzaga é chamado de Rei do Baião."],
jazz:["A improvisação é a marca do jazz: a mesma música soa diferente a cada apresentação.","Louis Armstrong era conhecido como Satchmo."],
rock:["Nos anos 1960, os Beatles ajudaram a levar o rock para o mundo inteiro.","Rita Lee é lembrada como a Rainha do Rock brasileiro."],
metal:["O gesto do “chifrinho” com a mão ficou famoso no metal por causa de Ronnie James Dio.","O Sepultura, de Belo Horizonte, é uma das bandas brasileiras de metal mais conhecidas do mundo."],
pop:["A palavra pop vem de “popular”.","Michael Jackson é conhecido como o Rei do Pop."]};
const app=document.getElementById("app");
const disc=(g,t)=>`<div class="dw" ${t?"data-t":""} data-i="${g.i!=null?g.i:G.indexOf(g)}" style="--c:${g.c}"></div>`;

function home(){
 const gold={n:"Universo",c:"#D4AF37",i:4},blue={n:"Musical",c:"#2F6FED",i:2};
 return `<div class="wrap"><section class="hero"><div><span class="tag">Museu musical interativo</span><h1>Uma viagem pelo <em>universo</em> musical</h1><p>Explore a história, a diversidade e a identidade dos gêneros musicais. Cada disco da estante guarda um estilo diferente.</p></div><div class="duo">${disc(gold,1)}${disc(blue,1)}</div></section>
 <section class="sec" id="estante"><h2>Estante de discos</h2><p class="hint" id="hint">Passe o mouse e clique em um disco para explorar o gênero.</p>
 <div class="shelf">${G.map((g,i)=>`<a class="card" data-t href="#${g.s}" style="--c:${g.c};animation-delay:${i*45}ms">${disc(g)}<h3>${g.n}</h3><p>${g.f}</p></a>`).join("")}</div></section>
 <section class="sec" id="sobre" style="padding-bottom:70px"><h2>Sobre o projeto</h2><p class="hint" style="max-width:40em">Universo Musical é um projeto escolar sobre 15 gêneros musicais. O disco de vinil é a identidade do site: gira, reage ao mouse e leva à página de cada estilo.</p></section></div>`;
}
function genre(g){
 const i=G.indexOf(g),p=G[(i+14)%15],n=G[(i+1)%15];
 return `<div class="wrap" style="--c:${g.c}"><button class="back" onclick="location.hash='inicio'">← Voltar aos gêneros</button>
 <section class="gh"><div><div class="feel">${g.f}</div><h1>${g.n}</h1><p>${g.o}</p>
 <div class="pills">${[["origem","Origem"],["car","Características"],["art","Artistas"],["cur","Curiosidades"],["mus","Músicas"]].map(x=>`<button data-go="${x[0]}">${x[1]}</button>`).join("")}</div></div><div class="big">${disc(g,1)}</div></section>
 <section class="block" id="origem"><h2>Origem e história</h2><p style="max-width:44em;color:#d6dbe8">${g.o}</p></section>
 <section class="block" id="car"><h2>Principais características</h2><div class="three">${["Ritmo","Instrumentos","Letras"].map((t,j)=>`<div class="box"><b>${t}</b><span>${g.k[j]}</span></div>`).join("")}</div></section>
 <section class="block" id="art"><h2>Artistas importantes</h2><div class="arts">${g.a.map(a=>`<div class="art"><div class="av">${a[0]}</div><b>${a}</b></div>`).join("")}</div></section>
 <section class="block" id="cur"><h2>Curiosidades</h2><div class="three" style="grid-template-columns:repeat(2,1fr)">${C[g.s].map(t=>`<div class="box"><span>${t}</span></div>`).join("")}</div></section>
 <section class="block" id="mus"><h2>Músicas que marcaram gerações</h2>${g.m.map((m,j)=>`<div class="song"><i>${j+1}</i><div><b>${m[0]}</b><small>${m[1]}</small></div><em>${m[2]}</em></div>`).join("")}</section>
 <div class="gnav"><a href="#${p.s}">← ${p.n}</a><a href="#inicio">Voltar aos gêneros</a><a href="#${n.s}">${n.n} →</a></div></div>`;
}
function bind(){
 const touch=matchMedia("(hover:none)").matches;
 if(touch){const h=document.getElementById("hint");if(h)h.textContent="Toque uma vez para destacar o disco e outra vez para abrir.";}
 document.querySelectorAll("[data-t]").forEach(el=>{
  el.addEventListener("pointermove",e=>{if(e.pointerType==="touch")return;const r=el.getBoundingClientRect();el._ty=((e.clientY-r.top)/r.height-.5)*.55;el._tx=((e.clientX-r.left)/r.width-.5)*.55});
  el.addEventListener("pointerleave",()=>{el._tx=0;el._ty=0});
 });
 document.querySelectorAll(".card").forEach(c=>c.addEventListener("click",e=>{
  if(touch&&!c.classList.contains("on")){e.preventDefault();document.querySelectorAll(".card.on").forEach(x=>x.classList.remove("on"));c.classList.add("on");}
 }));
 document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>document.getElementById(b.dataset.go).scrollIntoView()));
}
function route(){
 const h=location.hash.slice(1),g=G.find(x=>x.s===h);
 app.innerHTML=g?genre(g):home();document.title=g?g.n+" · Universo Musical":"Universo Musical";
 if(h==="sobre"){document.getElementById("sobre").scrollIntoView();}else window.scrollTo(0,0);
 bind();glScan();
}
(function(){const b=document.createElement("div");b.id="bg";let h='<i class="gv a"></i><i class="gv b"></i>';
for(const sd of["l","r"]){h+='<div class="wv '+sd+'">';for(let i=0;i<14;i++){const v=Math.abs(Math.sin(i*.9+(sd=="l"?0:1.7)))*.7+.3;h+='<i style="--h:'+Math.round(v*34+6)+'vh;--d:'+(i*-.23).toFixed(2)+'s"></i>'}h+='</div>'}
for(let i=0;i<26;i++){const s=2+Math.random()*3.5;h+='<b class="ld" style="left:'+(Math.random()*100).toFixed(1)+'%;top:'+(Math.random()*100).toFixed(1)+'%;width:'+s.toFixed(1)+'px;height:'+s.toFixed(1)+'px;--k:'+(i%3?"#D4AF37":"#B890FF")+';animation-delay:'+(-Math.random()*9).toFixed(1)+'s;animation-duration:'+(6+Math.random()*7).toFixed(1)+'s"></b>'}
b.innerHTML=h;document.body.prepend(b)})();
addEventListener("hashchange",route);route();
